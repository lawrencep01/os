#!/bin/sh
sleep $1
echo "${@:2}"
