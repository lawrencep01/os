#!/bin/sh
sed -e 's/YYY/ZZZ/'
